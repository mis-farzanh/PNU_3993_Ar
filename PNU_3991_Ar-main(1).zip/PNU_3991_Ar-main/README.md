# PNU_3993_Ar
---
فاطمه فرزانه
---
 - [PNU_3993_Ar](https://github.com/fatemehfarzaneh/PNU_3991_Ar) 
 - [حساب گیت هاب](https://github.com/fatemehfarzaneh)
 
-  [رزومه](https://fatemehfarzaneh.github.io/PNU_3991_Ar/)
-  [SOP](https://github.com/fatemehfarzaneh/PNU_3991_Ar/blob/main/SOP)


-   [HTML](https://github.com/fatemehfarzaneh/PNU_3991_Ar/blob/main/cert-1014-24305552.jpg )
 -  [JavaScript certificate](https://github.com/fatemehfarzaneh/PNU_3991_Ar/blob/main/cert-24305552-1024.png)
 -  [patchwork]

----
#  ارزیابی
 -  [ارزیابی رزومه و انگیزه نامه](https://github.com/fatemehfarzaneh/PNU_3991_Ar/commit/d8646532fbb87e22fda36c821bd9679)
 -  [خلاصه ارزیابی بخش عمومی](https://github.com/fatemehfarzaneh/PNU_3991_Ar/blob/main/XX_GeneralSection_CheckList_AR_3991.docx)

----
# دروس کارشناسی
کارآموزی
-  [گزارش کارآموزی](https://github.com/fatemehfarzaneh/PNU_3991_Ar/blob/main/XX_internship_report_AR_3993.pdf)


